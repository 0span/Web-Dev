# khan-academy-intro-to-html-css
Exercises for the Khan Academy's Intro to HTML/CSS course
